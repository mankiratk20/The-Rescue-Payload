import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with User-Agent for AI Studio telemetry
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Paths & DB Setup
const DB_PATH = path.join(process.cwd(), "tasks-db.json");

interface Task {
  id: number;
  task_name: string;
  raw_mind_dump: string;
  deadline: string; // YYYY-MM-DD HH:MM:SS
  estimated_hours: number;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Pending' | 'In-Progress' | 'Completed' | 'Rescued';
  created_at: string;
}

// Initialize database with realistic seed tasks if it doesn't exist
function initDb() {
  if (!fs.existsSync(DB_PATH)) {
    const now = new Date();
    
    // Create Task 1: Due in 1 hour (takes 3 hours) - TRIGGERS EMERGENCY IMMEDIATELY
    const t1Deadline = new Date(now.getTime() + 1 * 60 * 60 * 1000);
    const t1Formatted = formatDbDate(t1Deadline);

    // Create Task 2: Due in 6 hours (takes 2 hours) - Safe for now
    const t2Deadline = new Date(now.getTime() + 6 * 60 * 60 * 1000);
    const t2Formatted = formatDbDate(t2Deadline);

    const initialTasks: Task[] = [
      {
        id: 1,
        task_name: "Complete Pitch Deck Financial Slides",
        raw_mind_dump: "Need to submit the slide deck in an hour but it easily takes 3 hours of focused formatting and data checks. High stress!",
        deadline: t1Formatted,
        estimated_hours: 3,
        priority: "Critical",
        status: "Pending",
        created_at: now.toISOString()
      },
      {
        id: 2,
        task_name: "Refactor Database Schema",
        raw_mind_dump: "Have to finish updating the relational tables by tonight, takes around 2 hours.",
        deadline: t2Formatted,
        estimated_hours: 2,
        priority: "Medium",
        status: "Pending",
        created_at: now.toISOString()
      }
    ];
    fs.writeFileSync(DB_PATH, JSON.stringify(initialTasks, null, 2), "utf8");
  }
}

function formatDbDate(date: Date): string {
  const pad = (num: number) => String(num).padStart(2, '0');
  const yyyy = date.getUTCFullYear();
  const mm = pad(date.getUTCMonth() + 1);
  const dd = pad(date.getUTCDate());
  const hh = pad(date.getUTCHours());
  const min = pad(date.getUTCMinutes());
  const ss = pad(date.getUTCSeconds());
  return `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
}

function readTasks(): Task[] {
  try {
    if (!fs.existsSync(DB_PATH)) {
      initDb();
    }
    const data = fs.readFileSync(DB_PATH, "utf8");
    return JSON.parse(data) as Task[];
  } catch (error) {
    console.error("Error reading database:", error);
    return [];
  }
}

function writeTasks(tasks: Task[]) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(tasks, null, 2), "utf8");
  } catch (error) {
    console.error("Error writing database:", error);
  }
}

// Robust helper function to execute generateContent with retry logic and model fallbacks
async function generateContentWithRetry(params: { contents: any; config?: any }, maxRetries = 2) {
  const modelsToTry = [
    "gemini-2.5-flash",
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite",
    "gemini-flash-latest"
  ];

  let lastError: any = null;

  for (const modelName of modelsToTry) {
    let attempts = 0;
    while (attempts <= maxRetries) {
      try {
        console.log(`Attempting generateContent using model: ${modelName} (attempt ${attempts + 1})`);
        const response = await ai.models.generateContent({
          ...params,
          model: modelName,
        });
        return response;
      } catch (error: any) {
        lastError = error;
        const status = error.status || (error.error && error.error.status);
        const code = error.code || (error.error && error.error.code);
        const message = error.message || "";
        console.error(`Error with model ${modelName} on attempt ${attempts + 1}:`, error);

        const isTransient = 
          code === 503 || 
          status === "UNAVAILABLE" || 
          code === 429 || 
          status === "RESOURCE_EXHAUSTED" ||
          message.includes("503") ||
          message.includes("UNAVAILABLE") ||
          message.includes("high demand") ||
          message.includes("exhausted") ||
          message.includes("429");

        if (isTransient) {
          attempts++;
          if (attempts <= maxRetries) {
            const delay = Math.pow(2, attempts) * 300; // Exponential backoff (600ms, 1200ms, etc.)
            console.log(`Transient error. Retrying ${modelName} in ${delay}ms...`);
            await new Promise((resolve) => setTimeout(resolve, delay));
            continue;
          }
        }
        break;
      }
    }
    console.log(`Model ${modelName} failed all attempts or had non-transient error. Moving to next model...`);
  }

  throw lastError || new Error("All models failed to generate content.");
}

// API Routes

// GET /api/tasks - Retrieve all tasks
app.get("/api/tasks", (req, res) => {
  const tasks = readTasks();
  res.json({ success: true, tasks });
});

// POST /api/vibe - Parse chaotic mind-dump using Gemini and save to DB
app.post("/api/vibe", async (req, res) => {
  const { mind_dump } = req.body;

  if (!mind_dump || typeof mind_dump !== "string" || mind_dump.trim() === "") {
    return res.status(400).json({ success: false, error: "Input cannot be empty" });
  }

  if (!process.env.GEMINI_API_KEY) {
    return res.status(500).json({ 
      success: false, 
      error: "Gemini API key is not configured. Please add it in the Settings > Secrets panel." 
    });
  }

  try {
    // Current application time context is June 25, 2026.
    const currentTimeContext = "2026-06-25T01:55:29-07:00";
    
    const systemInstruction = `You are the processing core of "The Last-Minute Life Saver," a proactive AI productivity application. Your job is to take disorganized, panicked thoughts, texts, or audio transcripts from a user and extract a clean task payload. You must output ONLY raw valid JSON matching the requested schema. Use the reference current time of ${currentTimeContext} to resolve relative dates like "today at 4 PM" or "tomorrow morning". Year must be 2026.`;

    const prompt = `Parse this disorganized text and extract task properties:\n\n"${mind_dump}"`;

    const response = await generateContentWithRetry({
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            task_name: {
              type: Type.STRING,
              description: "A short, elegant, action-oriented name of the task."
            },
            deadline: {
              type: Type.STRING,
              description: "The calculated exact deadline timestamp formatted strictly as YYYY-MM-DD HH:MM:SS."
            },
            estimated_hours: {
              type: Type.INTEGER,
              description: "Estimated integer hours required to complete this task (minimum 1)."
            },
            priority: {
              type: Type.STRING,
              description: "Priority score: Low, Medium, High, or Critical."
            }
          },
          required: ["task_name", "deadline", "estimated_hours", "priority"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("Empty response from Gemini parsing engine.");
    }

    const cleanJson = JSON.parse(text.trim());

    // Basic safety validation
    const estHours = Math.max(1, parseInt(cleanJson.estimated_hours) || 1);
    const priority = ['Low', 'Medium', 'High', 'Critical'].includes(cleanJson.priority)
      ? cleanJson.priority
      : 'Medium';

    const tasks = readTasks();
    const newId = tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1;

    const newTask: Task = {
      id: newId,
      task_name: cleanJson.task_name || "Untitled Urgent Task",
      raw_mind_dump: mind_dump,
      deadline: cleanJson.deadline || formatDbDate(new Date(Date.now() + 2 * 60 * 60 * 1000)),
      estimated_hours: estHours,
      priority: priority as any,
      status: "Pending",
      created_at: new Date().toISOString()
    };

    tasks.push(newTask);
    writeTasks(tasks);

    res.json({ success: true, task: newTask });
  } catch (error: any) {
    console.error("Gemini Parsing/Storage Error:", error);
    res.status(500).json({ 
      success: false, 
      error: error.message || "Failed to process mind-dump with Gemini AI." 
    });
  }
});

// GET /api/emergency - Calculate proactively if user is running out of time
app.get("/api/emergency", (req, res) => {
  const tasks = readTasks();
  const now = new Date();
  
  let emergencyTask: any = null;

  for (const task of tasks) {
    if (task.status === "Pending" || task.status === "In-Progress") {
      const deadline = new Date(task.deadline.replace(' ', 'T') + "Z"); // Standard ISO compatibility with UTC
      const msLeft = deadline.getTime() - now.getTime();
      const hoursLeft = msLeft / (1000 * 60 * 60);

      // Trigger if deadline is closer than estimated hours and deadline hasn't fully passed (or is very recently passed within 1 hour)
      if (hoursLeft <= task.estimated_hours && hoursLeft > -1.0) {
        emergencyTask = {
          ...task,
          hours_left: Math.round(hoursLeft * 10) / 10
        };
        break; // Grab the first critical item
      }
    }
  }

  if (emergencyTask) {
    res.json({ emergency: true, task: emergencyTask });
  } else {
    res.json({ emergency: false });
  }
});

// POST /api/tasks/action - Autonomous extension request drafting via Gemini
app.post("/api/tasks/action", async (req, res) => {
  const { taskId } = req.body;

  const tasks = readTasks();
  const task = tasks.find(t => t.id === Number(taskId));

  if (!task) {
    return res.status(404).json({ success: false, error: "Task not found" });
  }

  if (!process.env.GEMINI_API_KEY) {
    return res.status(500).json({ success: false, error: "Gemini API key is not configured." });
  }

  try {
    const prompt = `You are 'The Last-Minute Life Saver' AI extension drafting engine.
Write a highly professional, polite, persuasive, and custom-tailored message or email to a manager, teacher, or client requesting a reasonable deadline extension.
The message must feel deeply authentic, completely avoiding cliché robotic templates, and express sincere commitment to quality.

TASK INFORMATION:
- Task: "${task.task_name}"
- Original Deadline: "${task.deadline}"
- Raw panic mind-dump: "${task.raw_mind_dump}"
- Estimated hours remaining: ${task.estimated_hours} hours

Format the output nicely. Provide a subject line if appropriate, followed by the message body. Do not include any meta-commentary, markdown backticks, or outer labels outside of the message text itself.`;

    const response = await generateContentWithRetry({
      contents: prompt,
    });

    const draft = response.text || "Failed to generate a draft.";

    // Automatically transition the task status to 'Rescued' to indicate active containment!
    task.status = "Rescued";
    writeTasks(tasks);

    res.json({ success: true, draft, task });
  } catch (error: any) {
    console.error("Rescue Drafting Error:", error);
    res.status(500).json({ success: false, error: "Failed to draft extension request via Gemini." });
  }
});

// POST /api/tasks/update-status - Update a task's status manually
app.post("/api/tasks/update-status", (req, res) => {
  const { id, status } = req.body;

  const tasks = readTasks();
  const task = tasks.find(t => t.id === Number(id));

  if (!task) {
    return res.status(404).json({ success: false, error: "Task not found." });
  }

  if (!['Pending', 'In-Progress', 'Completed', 'Rescued'].includes(status)) {
    return res.status(400).json({ success: false, error: "Invalid status value." });
  }

  task.status = status;
  writeTasks(tasks);

  res.json({ success: true, task });
});

// DELETE /api/tasks/:id - Delete a task
app.delete("/api/tasks/:id", (req, res) => {
  const id = Number(req.params.id);
  const tasks = readTasks();
  const filtered = tasks.filter(t => t.id !== id);

  if (tasks.length === filtered.length) {
    return res.status(404).json({ success: false, error: "Task not found." });
  }

  writeTasks(filtered);
  res.json({ success: true });
});

// Initialize DB before starting server
initDb();

// Vite integration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`The Last-Minute Life Saver server is running on http://localhost:${PORT}`);
  });
}

startServer();
