import './index.css';

interface Task {
  id: number;
  task_name: string;
  raw_mind_dump: string;
  deadline: string; // YYYY-MM-DD HH:MM:SS
  estimated_hours: number;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Pending' | 'In-Progress' | 'Completed' | 'Rescued';
  created_at: string;
}

const PRESETS = [
  {
    label: "🔥 Late Presentation Deck",
    text: "Need to submit the slides deck in an hour but it easily takes 3 hours of focused formatting. High stress!"
  },
  {
    label: "📝 Essay Panic",
    text: "Okay so I have this huge math essay that's due at 6 PM today. I really need about 3 hours to write the whole thing and format the bibliography but it's already 4 PM and I haven't started. High priority obviously!"
  },
  {
    label: "📊 Investor Pitch Prep",
    text: "Gotta present the pitch deck to the investors tomorrow at 9 AM. I need to spend 2 hours refining the financial slides. It's medium priority for now but need it tracked."
  }
];

// Application State
let tasks: Task[] = [];
let isProcessing = false;
let isDrafting = false;
let draftedRescue: { draft: string; taskName: string; id: number } | null = null;
let systemTime = new Date();
let toastTimeout: any = null;

// DOM Elements
const vibeForm = document.getElementById('vibe-form') as HTMLFormElement;
const mindDumpInput = document.getElementById('mind-dump') as HTMLTextAreaElement;
const charCounter = document.getElementById('char-counter') as HTMLSpanElement;
const submitBtn = document.getElementById('submit-btn') as HTMLButtonElement;
const presetsList = document.getElementById('presets-list') as HTMLDivElement;
const systemDateEl = document.getElementById('system-date') as HTMLSpanElement;
const systemTimeEl = document.getElementById('system-time') as HTMLSpanElement;
const emergencyAlertContainer = document.getElementById('emergency-alert-container') as HTMLDivElement;
const rescueDraftContainer = document.getElementById('rescue-draft-container') as HTMLDivElement;
const pendingCountEl = document.getElementById('pending-count') as HTMLElement;
const rescuedCountEl = document.getElementById('rescued-count') as HTMLElement;
const tasksContainer = document.getElementById('tasks-container') as HTMLDivElement;
const toastEl = document.getElementById('toast') as HTMLDivElement;
const toastMessageEl = document.getElementById('toast-message') as HTMLSpanElement;

// Helper to display floating status toasts
function showToast(message: string) {
  if (toastTimeout) {
    clearTimeout(toastTimeout);
  }
  toastMessageEl.textContent = message;
  toastEl.classList.remove('opacity-0', 'translate-y-[-20px]', 'pointer-events-none');
  toastEl.classList.add('opacity-100', 'translate-y-0');

  toastTimeout = setTimeout(() => {
    toastEl.classList.remove('opacity-100', 'translate-y-0');
    toastEl.classList.add('opacity-0', 'translate-y-[-20px]', 'pointer-events-none');
  }, 4000);
}

// Utility formatting functions
function formatTime(date: Date): string {
  return date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
}

function formatDate(date: Date): string {
  return date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" });
}

// Update character counter and button state
function updateTextareaState() {
  const len = mindDumpInput.value.length;
  charCounter.textContent = `Length: ${len} chars`;
  submitBtn.disabled = isProcessing || len === 0;
}

mindDumpInput.addEventListener('input', updateTextareaState);

// Render presets dynamically
function initPresets() {
  presetsList.innerHTML = '';
  PRESETS.forEach((preset) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = "w-full text-left p-3 rounded-lg bg-slate-900/40 hover:bg-slate-900/95 border border-slate-800 hover:border-slate-700/60 transition-all text-xs flex justify-between items-start gap-3 group cursor-pointer";
    btn.innerHTML = `
      <div class="space-y-0.5">
        <div class="font-semibold text-slate-300 group-hover:text-blue-400 transition-colors">${preset.label}</div>
        <div class="text-slate-500 line-clamp-1 text-[11px] font-mono">${preset.text}</div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate-600 shrink-0 mt-0.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
    `;
    btn.addEventListener('click', () => {
      mindDumpInput.value = preset.text;
      updateTextareaState();
      showToast(`📝 Loaded preset: ${preset.label}`);
    });
    presetsList.appendChild(btn);
  });
}

// Handle vibe dump submission
vibeForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const mindDumpVal = mindDumpInput.value.trim();
  if (!mindDumpVal) return;

  isProcessing = true;
  submitBtn.disabled = true;
  submitBtn.textContent = "PROCESSING...";

  try {
    const res = await fetch("/api/vibe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mind_dump: mindDumpVal })
    });
    const data = await res.json();
    if (data.success) {
      mindDumpInput.value = "";
      updateTextareaState();
      showToast(`✨ Task "${data.task.task_name}" successfully processed and locked in!`);
      await fetchTasks();
      await checkEmergency();
    } else {
      showToast(`❌ Error: ${data.error}`);
    }
  } catch (err) {
    showToast("❌ Connection failure when parsing text.");
  } finally {
    isProcessing = false;
    submitBtn.textContent = "PROCESS VIBE";
    updateTextareaState();
  }
});

// Fetch tasks list
async function fetchTasks() {
  try {
    const res = await fetch("/api/tasks");
    const data = await res.json();
    if (data.success) {
      tasks = data.tasks;
      renderTasks();
    }
  } catch (err) {
    console.error("Error fetching tasks:", err);
  }
}

// Fetch emergency state
async function checkEmergency() {
  try {
    const res = await fetch("/api/emergency");
    const data = await res.json();
    renderEmergency(data);
  } catch (err) {
    console.error("Error checking emergency:", err);
  }
}

// Trigger Gemini extension draft
async function triggerRescue(taskId: number) {
  if (isDrafting) return;
  isDrafting = true;
  showToast("⏳ Contacting Gemini agent for a customized rescue response...");

  try {
    const res = await fetch("/api/tasks/action", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ taskId })
    });
    const data = await res.json();
    if (data.success) {
      draftedRescue = {
        draft: data.draft,
        taskName: data.task.task_name,
        id: data.task.id
      };
      showToast("🚨 AI rescue draft calculated and compiled!");
      renderRescueDraft();
      await fetchTasks();
      await checkEmergency();
    } else {
      showToast(`❌ Drafting error: ${data.error}`);
    }
  } catch (err) {
    showToast("❌ Server connection lost while drafting rescue payload.");
  } finally {
    isDrafting = false;
  }
}

// Update manual status dropdown
async function updateStatus(id: number, status: string) {
  try {
    const res = await fetch("/api/tasks/update-status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status })
    });
    const data = await res.json();
    if (data.success) {
      showToast(`💼 Status updated to ${status}`);
      await fetchTasks();
      await checkEmergency();
    }
  } catch (err) {
    showToast("❌ Failed to update task status.");
  }
}

// Delete task
async function deleteTask(id: number) {
  try {
    const res = await fetch(`/api/tasks/${id}`, {
      method: "DELETE"
    });
    const data = await res.json();
    if (data.success) {
      showToast("🗑️ Task safely archived and removed.");
      if (draftedRescue?.id === id) {
        draftedRescue = null;
        renderRescueDraft();
      }
      await fetchTasks();
      await checkEmergency();
    }
  } catch (err) {
    showToast("❌ Archiving failure.");
  }
}

// Copy draft payload
function copyToClipboard(text: string, buttonEl: HTMLButtonElement) {
  navigator.clipboard.writeText(text);
  showToast("📋 Copied to clipboard successfully!");
  
  const originalHTML = buttonEl.innerHTML;
  buttonEl.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-emerald-400"><polyline points="20 6 9 17 4 12"/></svg>
    Copied!
  `;
  setTimeout(() => {
    buttonEl.innerHTML = originalHTML;
  }, 2000);
}

// Render emergency panel
function renderEmergency(data: any) {
  if (data.emergency && data.task) {
    const task = data.task;
    emergencyAlertContainer.innerHTML = `
      <div class="bg-red-950/20 border-2 border-red-500/50 rounded-2xl p-6 flex flex-col justify-between relative overflow-hidden shadow-2xl shadow-red-950/30">
        <div class="absolute -right-8 -top-8 w-40 h-40 bg-red-500/5 rounded-full blur-3xl pointer-events-none"></div>
        
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10 mb-4">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 bg-red-600 rounded flex items-center justify-center shadow-lg shadow-red-950/40 shrink-0">
              <span class="text-white font-bold text-base">!</span>
            </div>
            <div>
              <h2 class="text-red-400 font-bold tracking-tight text-base sm:text-lg">CRITICAL INTERVENTION DETECTED</h2>
              <p class="text-slate-300 text-xs sm:text-sm">Automated rescue protocol required for pending deadline.</p>
            </div>
          </div>
          <div class="px-3 py-1 bg-red-500/20 border border-red-500/30 rounded-full shrink-0">
            <span class="text-[10px] text-red-400 font-bold uppercase tracking-widest font-mono">Imminent Failure</span>
          </div>
        </div>

        <div class="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 relative z-10 mt-2 pt-2 border-t border-red-950/50">
          <div class="space-y-1">
            <p class="text-xs text-slate-300">
              Critical Task: <span class="text-white font-semibold">"${task.task_name}"</span>
            </p>
            <p class="text-[11px] text-slate-400 font-mono">
              TIME_LEFT: <span class="text-red-400 font-bold uppercase">${task.hours_left > 0 ? `${task.hours_left}H` : 'OVERDUE'}</span> // ESTIMATED_REQD: <span class="text-slate-200 uppercase">${task.estimated_hours}H</span>
            </p>
          </div>
          <button
            id="emergency-rescue-btn"
            class="w-full sm:w-auto px-5 py-2.5 bg-white hover:bg-slate-200 text-slate-950 text-xs font-bold rounded-lg transition-all active:scale-95 shrink-0 uppercase tracking-wide cursor-pointer"
          >
            DRAFT EXTENSION REQUEST
          </button>
        </div>
      </div>
    `;

    document.getElementById('emergency-rescue-btn')?.addEventListener('click', () => {
      triggerRescue(task.id);
    });
  } else {
    emergencyAlertContainer.innerHTML = `
      <div class="h-44 bg-slate-900/30 border border-slate-800/80 rounded-2xl p-6 flex flex-col justify-between relative overflow-hidden">
        <div class="absolute -right-8 -top-8 w-40 h-40 bg-slate-800/20 rounded-full blur-3xl"></div>
        
        <div class="flex justify-between items-start relative z-10">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 bg-slate-800 rounded flex items-center justify-center">
              <span class="text-slate-400 font-bold">✓</span>
            </div>
            <div>
              <h2 class="text-slate-300 font-bold tracking-tight text-base sm:text-lg">SURVEILLANCE INTEGRITY HIGH</h2>
              <p class="text-slate-500 text-xs sm:text-sm">All monitored task deadlines currently maintain positive buffer margins.</p>
            </div>
          </div>
          <div class="px-3 py-1 bg-slate-800/60 border border-slate-700/30 rounded-full">
            <span class="text-[10px] text-emerald-500 font-mono font-bold uppercase tracking-widest">Normal Ops</span>
          </div>
        </div>

        <div class="flex items-end justify-between relative z-10 mt-4">
          <div class="space-y-1">
            <p class="text-xs text-slate-400">Next surveillance tick is scheduled in background.</p>
            <p class="text-[11px] text-slate-500 font-mono">ALL_BUFFERS_GREEN // SECURE</p>
          </div>
        </div>
      </div>
    `;
  }
}

// Render generated rescue draft
function renderRescueDraft() {
  if (draftedRescue) {
    rescueDraftContainer.classList.remove('hidden');
    rescueDraftContainer.innerHTML = `
      <div class="bg-slate-900 border border-emerald-500/40 rounded-2xl p-6 shadow-2xl relative">
        <div class="absolute -right-8 -top-8 w-40 h-40 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>

        <div class="flex items-center justify-between mb-4 pb-3 border-b border-slate-800 relative z-10">
          <div class="flex items-center gap-2">
            <span class="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-emerald-400 animate-pulse"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
            </span>
            <h3 class="font-bold text-slate-100 text-sm sm:text-base">
              AI Generated Rescue Payload
            </h3>
          </div>
          <button
            id="close-rescue-btn"
            class="text-slate-400 hover:text-slate-200 text-xs px-2 py-1 rounded bg-slate-950 border border-slate-800 cursor-pointer font-mono"
          >
            CLOSE_PANEL
          </button>
        </div>
        
        <div class="text-xs text-slate-400 mb-2 relative z-10 font-mono">
          DRAFTED_FOR: <strong class="text-slate-200">"${draftedRescue.taskName}"</strong>
        </div>

        <div class="bg-slate-950 border border-slate-850 rounded-xl p-4 font-mono text-xs text-emerald-300 whitespace-pre-wrap leading-relaxed max-h-72 overflow-y-auto mb-4 scrollbar-thin scrollbar-thumb-slate-800 relative z-10">
          ${draftedRescue.draft}
        </div>

        <div class="flex justify-end gap-3 relative z-10">
          <button
            id="copy-rescue-btn"
            class="px-4 py-2 bg-slate-950 hover:bg-slate-900 border border-slate-850 hover:border-slate-700 text-slate-200 text-xs font-semibold rounded-lg flex items-center gap-2 transition-all cursor-pointer"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate-400"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
            Copy to Clipboard
          </button>
        </div>
      </div>
    `;

    document.getElementById('close-rescue-btn')?.addEventListener('click', () => {
      draftedRescue = null;
      renderRescueDraft();
    });

    const copyBtn = document.getElementById('copy-rescue-btn') as HTMLButtonElement;
    copyBtn?.addEventListener('click', () => {
      if (draftedRescue) {
        copyToClipboard(draftedRescue.draft, copyBtn);
      }
    });
  } else {
    rescueDraftContainer.classList.add('hidden');
    rescueDraftContainer.innerHTML = '';
  }
}

// Render Structured Task Monitor list
function renderTasks() {
  const pendingCount = tasks.filter(t => t.status === "Pending" || t.status === "In-Progress").length;
  const rescuedCount = tasks.filter(t => t.status === "Rescued" || t.status === "Completed").length;

  pendingCountEl.textContent = String(pendingCount);
  rescuedCountEl.textContent = String(rescuedCount);

  if (tasks.length === 0) {
    tasksContainer.innerHTML = `
      <div class="flex-1 flex flex-col items-center justify-center text-center py-12 border border-dashed border-slate-800 rounded-2xl bg-slate-950/20" id="empty_state">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate-700 mx-auto mb-3"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/></svg>
        <h4 class="text-slate-400 font-mono text-xs uppercase tracking-wider mb-1">No Active Tasks</h4>
        <p class="text-xs text-slate-500 max-w-xs mx-auto">
          Dump chaotic notes in the left side input or select an evaluator preset to feed the surveillance engine.
        </p>
      </div>
    `;
    return;
  }

  let listHtml = `<div class="space-y-3" id="tasks_list">`;

  tasks.forEach((task) => {
    const deadlineDate = new Date(task.deadline.replace(' ', 'T') + "Z");
    const msLeft = deadlineDate.getTime() - systemTime.getTime();
    const hoursLeft = msLeft / (1000 * 60 * 60);
    const isOverdue = hoursLeft <= 0;
    const isUrgent = hoursLeft > 0 && hoursLeft <= task.estimated_hours;

    const isPendingOrInProgress = task.status === "Pending" || task.status === "In-Progress";

    let borderClass = "border-slate-800/80";
    let bgClass = "bg-slate-900/50";
    if (isOverdue && isPendingOrInProgress) {
      bgClass = "bg-red-950/10";
      borderClass = "border-red-900/40";
    } else if (isUrgent && isPendingOrInProgress) {
      bgClass = "bg-rose-950/20";
      borderClass = "border-rose-500/30";
    }

    const opacityClass = task.status === "Completed" ? "opacity-60" : "";

    let priorityBadgeClass = "bg-slate-800/50 text-slate-400 border border-slate-700/20";
    if (task.priority === "Critical") {
      priorityBadgeClass = "bg-red-500/10 text-red-400 border border-red-500/20";
    } else if (task.priority === "High") {
      priorityBadgeClass = "bg-orange-500/10 text-orange-400 border border-orange-500/20";
    } else if (task.priority === "Medium") {
      priorityBadgeClass = "bg-blue-500/10 text-blue-400 border border-blue-500/20";
    }

    let bufferText = "";
    let bufferColorClass = "text-emerald-400";
    if (isOverdue && isPendingOrInProgress) {
      bufferText = "OVERDUE";
      bufferColorClass = "text-red-400";
    } else if (hoursLeft > 0) {
      bufferText = `${Math.round(hoursLeft * 10) / 10}h left`;
      if (isUrgent) bufferColorClass = "text-rose-400";
    } else {
      bufferText = `${Math.abs(Math.round(hoursLeft * 10) / 10)}h overdue`;
      bufferColorClass = "text-red-400";
    }

    const shortDeadlineTime = task.deadline.split(' ')[1] || task.deadline;

    listHtml += `
      <div
        class="grid grid-cols-1 lg:grid-cols-12 items-center p-4 rounded-xl hover:border-slate-700 transition-all gap-4 border ${bgClass} ${borderClass} ${opacityClass}"
        id="task_card_${task.id}"
      >
        <!-- Name & Dump -->
        <div class="lg:col-span-5 space-y-1">
          <div class="flex items-center gap-2.5 flex-wrap">
            <p class="text-sm font-semibold text-slate-100">${task.task_name}</p>
            ${isUrgent && isPendingOrInProgress ? '<span class="inline-block w-2 h-2 rounded-full bg-red-500 animate-ping"></span>' : ''}
          </div>
          <p class="text-[11px] text-slate-500 italic truncate font-mono max-w-sm">
            "${task.raw_mind_dump}"
          </p>
        </div>

        <!-- Priority -->
        <div class="lg:col-span-2 text-left lg:text-center shrink-0">
          <p class="text-[9px] text-slate-500 uppercase font-mono tracking-wider block lg:hidden">Priority</p>
          <span class="inline-block text-[10px] px-2.5 py-0.5 font-mono rounded ${priorityBadgeClass}">
            ${task.priority.toUpperCase()}
          </span>
        </div>

        <!-- Est. Hours -->
        <div class="lg:col-span-1 text-left lg:text-center shrink-0">
          <p class="text-[9px] text-slate-500 uppercase font-mono tracking-wider block lg:hidden">Est. Hours</p>
          <p class="text-xs sm:text-sm font-mono text-slate-300">${task.estimated_hours}h</p>
        </div>

        <!-- Remaining / Deadline -->
        <div class="lg:col-span-2 text-left lg:text-center shrink-0">
          <p class="text-[9px] text-slate-500 uppercase font-mono tracking-wider block lg:hidden">Buffer</p>
          <p class="task-buffer text-xs font-mono font-bold ${bufferColorClass}" data-task-id="${task.id}">
            ${bufferText}
          </p>
          <span class="text-[10px] text-slate-500 font-mono block mt-0.5">
            ${shortDeadlineTime}
          </span>
        </div>

        <!-- Status select & Actions Column -->
        <div class="lg:col-span-2 flex items-center justify-between lg:justify-end gap-2.5 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-800/50 shrink-0">
          
          <!-- Status Select -->
          <select
            data-task-id="${task.id}"
            class="status-select bg-slate-950 border border-slate-800 text-slate-300 text-[11px] rounded-md px-2 py-1 focus:ring-1 focus:ring-blue-500 focus:outline-none cursor-pointer font-mono shrink-0"
          >
            <option value="Pending" ${task.status === "Pending" ? "selected" : ""}>Pending</option>
            <option value="In-Progress" ${task.status === "In-Progress" ? "selected" : ""}>In-Progress</option>
            <option value="Completed" ${task.status === "Completed" ? "selected" : ""}>Completed</option>
            <option value="Rescued" ${task.status === "Rescued" ? "selected" : ""}>Rescued</option>
          </select>

          <div class="flex items-center gap-1.5 shrink-0">
            <!-- Manual AI trigger rescue -->
            <button
              data-task-id="${task.id}"
              title="Rescue Task"
              class="rescue-btn p-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-sparkles"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275Z"/><path d="m5 3 1 2.5L8.5 6 6 7 5 9.5 4 7 1.5 6 4 5.5Z"/><path d="m19 17 1 2.5 2.5.5-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1Z"/></svg>
            </button>

            <!-- Delete Task -->
            <button
              data-task-id="${task.id}"
              title="Archive Task"
              class="delete-btn p-1.5 bg-slate-950 hover:bg-red-950/40 border border-slate-800 hover:border-red-900/50 rounded text-slate-500 hover:text-red-400 transition-all cursor-pointer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-trash-2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
            </button>
          </div>

        </div>
      </div>
    `;
  });

  listHtml += `</div>`;
  tasksContainer.innerHTML = listHtml;

  // Wire up event listeners for newly rendered items
  tasksContainer.querySelectorAll('.status-select').forEach((el) => {
    el.addEventListener('change', (e) => {
      const select = e.currentTarget as HTMLSelectElement;
      const id = Number(select.dataset.taskId);
      updateStatus(id, select.value);
    });
  });

  tasksContainer.querySelectorAll('.rescue-btn').forEach((el) => {
    el.addEventListener('click', (e) => {
      const btn = e.currentTarget as HTMLButtonElement;
      const id = Number(btn.dataset.taskId);
      triggerRescue(id);
    });
  });

  tasksContainer.querySelectorAll('.delete-btn').forEach((el) => {
    el.addEventListener('click', (e) => {
      const btn = e.currentTarget as HTMLButtonElement;
      const id = Number(btn.dataset.taskId);
      deleteTask(id);
    });
  });
}

// Clock updates
function updateClock() {
  systemTime = new Date();
  systemDateEl.textContent = formatDate(systemTime);
  systemTimeEl.textContent = formatTime(systemTime);
}

// In-place update of remaining buffer times on task cards
function updateBuffers() {
  tasks.forEach((task) => {
    const bufferEl = document.querySelector(`.task-buffer[data-task-id="${task.id}"]`);
    if (!bufferEl) return;

    const deadlineDate = new Date(task.deadline.replace(' ', 'T') + "Z");
    const msLeft = deadlineDate.getTime() - systemTime.getTime();
    const hoursLeft = msLeft / (1000 * 60 * 60);
    const isOverdue = hoursLeft <= 0;
    const isUrgent = hoursLeft > 0 && hoursLeft <= task.estimated_hours;

    const isPendingOrInProgress = task.status === "Pending" || task.status === "In-Progress";

    let bufferText = "";
    let bufferColorClass = "text-emerald-400";
    if (isOverdue && isPendingOrInProgress) {
      bufferText = "OVERDUE";
      bufferColorClass = "text-red-400";
    } else if (hoursLeft > 0) {
      bufferText = `${Math.round(hoursLeft * 10) / 10}h left`;
      if (isUrgent) bufferColorClass = "text-rose-400";
    } else {
      bufferText = `${Math.abs(Math.round(hoursLeft * 10) / 10)}h overdue`;
      bufferColorClass = "text-red-400";
    }

    // Update buffer element classes and text content
    bufferEl.className = `task-buffer text-xs font-mono font-bold ${bufferColorClass}`;
    bufferEl.textContent = bufferText;

    // Update overall card container style dynamically
    const cardEl = document.getElementById(`task_card_${task.id}`);
    if (cardEl) {
      let borderClass = "border-slate-800/80";
      let bgClass = "bg-slate-900/50";
      if (isOverdue && isPendingOrInProgress) {
        bgClass = "bg-red-950/10";
        borderClass = "border-red-900/40";
      } else if (isUrgent && isPendingOrInProgress) {
        bgClass = "bg-rose-950/20";
        borderClass = "border-rose-500/30";
      }
      const opacityClass = task.status === "Completed" ? "opacity-60" : "";
      cardEl.className = `grid grid-cols-1 lg:grid-cols-12 items-center p-4 rounded-xl hover:border-slate-700 transition-all gap-4 border ${bgClass} ${borderClass} ${opacityClass}`;
    }
  });
}

// Global Initialization
async function init() {
  initPresets();
  updateClock();
  
  // Real-time ticking clock every second
  setInterval(() => {
    updateClock();
    // Do a subtle non-blocking local update of remaining buffers in-place to keep UX fresh
    if (tasks.length > 0) {
      updateBuffers();
    }
  }, 1000);

  // Load initial data
  await fetchTasks();
  await checkEmergency();

  // Poll for emergency changes every 5 seconds (just like original React app)
  setInterval(() => {
    checkEmergency();
  }, 5000);
}

document.addEventListener('DOMContentLoaded', init);
// Run right away as fallback if DOMContentLoaded already fired
if (document.readyState === 'interactive' || document.readyState === 'complete') {
  init();
}
